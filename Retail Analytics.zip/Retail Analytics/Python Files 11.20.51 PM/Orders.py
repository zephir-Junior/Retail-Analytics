
import csv
import random
from faker import Faker
from datetime import datetime, timedelta

fake = Faker("en_US")

num_rows = int(input("Enter the number of orders to generate: "))
csv_file = input("Enter the name of the CSV file (e.g., data.csv): ")

def random_date(start_year=2020, end_year=2024):
    start_date = datetime(start_year, 1, 1)
    end_date = datetime(end_year, 12, 31)
    delta = end_date - start_date
    return (start_date + timedelta(days=random.randint(0, delta.days))).strftime("%Y-%m-%d")

with open("Orders.csv", mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["OrderID", "OrderDate", "ShipDate", "ShipMode", "Segment", "PostalCode", "CustomerID", "ProductID", "StoreID", "Quantity", "Sales", "Discount", "ShippingCost", "Profit"])

    for _ in range(num_rows):
        order_date = random_date()
        ship_date = (datetime.strptime(order_date, "%Y-%m-%d") + timedelta(days=random.randint(1, 10))).strftime("%Y-%m-%d")
        sales = round(random.uniform(50, 5000), 2)
        discount = round(random.uniform(0, 0.5) * sales, 2)
        shipping_cost = round(random.uniform(5, 50), 2)
        profit = round(sales - discount - shipping_cost, 2)

        writer.writerow([
            fake.uuid4(),
            order_date,
            ship_date,
            random.choice(["Standard", "Express", "Overnight"]),
            random.choice(["Consumer", "Corporate", "Small Business"]),
            fake.zipcode(),
            fake.uuid4(),
            fake.uuid4(),
            fake.uuid4(),
            random.randint(1, 10),
            sales,
            discount,
            shipping_cost,
            profit
        ])

print("csv_file generated successfully.")