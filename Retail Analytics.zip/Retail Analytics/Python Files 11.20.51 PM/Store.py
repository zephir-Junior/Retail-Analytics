
import csv
import random
from faker import Faker
from datetime import datetime, timedelta

fake = Faker("en_US")

num_rows = int(input("Enter the number of stores to generate: "))
csv_file = input("Enter the name of the CSV file (e.g., data.csv): ")

def random_date(start_year=2020, end_year=2024):
    start_date = datetime(start_year, 1, 1)
    end_date = datetime(end_year, 12, 31)
    delta = end_date - start_date
    return (start_date + timedelta(days=random.randint(0, delta.days))).strftime("%Y-%m-%d")

with open("Store.csv", mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["StoreID", "StoreName", "StoreType", "StoreOpeningDate", "ManagerName"])

    for _ in range(num_rows):
        writer.writerow([
            fake.uuid4(),
            fake.company(),
            random.choice(["Retail", "Wholesale", "Online"]),
            random_date(),
            fake.name()
        ])

print("csv_file generated successfully.")