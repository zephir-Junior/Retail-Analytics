
import csv
import random
from faker import Faker
from datetime import datetime

fake = Faker("en_US")

num_rows = int(input("Enter the number of customers to generate: "))
csv_file = input("Enter the name of the CSV file (e.g., data.csv): ")

with open(csv_file, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["CustomerID", "CustomerName", "Gender", "DOB", "Email", "Program_ID", "Postal_Code"])

    for _ in range(num_rows):
        writer.writerow([
            fake.uuid4(),
            fake.name(),
            random.choice(['M','F']),
            fake.date_of_birth(minimum_age=12, maximum_age=90).strftime("%Y-%m-%d"),
            fake.email(),
            random.choice([1, 2, 3, 4, 5, None]),
            fake.zipcode()
        ])

print("csv_file generated successfully.")