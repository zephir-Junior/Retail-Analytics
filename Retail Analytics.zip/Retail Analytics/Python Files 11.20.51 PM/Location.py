#import python libraries
import csv
import random
from faker import Faker

# Initialize Faker with a U.S. locale
fake = Faker("en_US")

# Define predefined U.S. regions and states
regions = ["Northeast", "Midwest", "South", "West"]
states = {
    "Northeast": ["New York", "Pennsylvania", "Massachusetts", "New Jersey", "Connecticut"],
    "Midwest": ["Illinois", "Ohio", "Michigan", "Indiana", "Wisconsin"],
    "South": ["Texas", "Florida", "Georgia", "North Carolina", "Tennessee"],
    "West": ["California", "Washington", "Oregon", "Nevada", "Arizona"]
}

# Fixed country name
country = "United States"

# User input for the number of rows and file name
num_rows = int(input("Enter the number of rows the CSV file should have: "))
csv_file = input("Enter the name of the CSV file (e.g., data.csv): ")

# Open the CSV file
with open(csv_file, mode='w', newline='') as file:
    writer = csv.writer(file)

    # Create and write the header
    header = ["Postal_Code", "City", "State", "Region", "Country", "Address"]
    writer.writerow(header)

    # Generate and write rows
    for _ in range(num_rows):
        region = random.choice(regions)  # Select a random region
        state = random.choice(states[region])  # Select a random state from the chosen region
        city = fake.city()  # Generate a random city
        postal_code = fake.zipcode()  # Generate a ZIP code
        address = fake.street_address()  # Generate a street address

        row = [postal_code, city, state, region, country, address]
        writer.writerow(row)

print(f"CSV file '{csv_file}' with {num_rows} rows has been created successfully.")

#Generate a Single row 


# write the row to the csv file 


#print success statement 

print(" the file has been loaded successfully") 
