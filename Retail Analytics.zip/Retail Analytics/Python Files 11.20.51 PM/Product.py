

import csv
import random
from faker import Faker

fake = Faker("en_US")

num_rows = int(input("Enter the number of products to generate: "))
csv_file = input("Enter the name of the CSV file (e.g., data.csv): ")

with open("Product.csv", mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["ProductID", "ProductName", "Category", "Sub_Category", "UnitPrice"])

    for _ in range(num_rows):
        writer.writerow([
            fake.uuid4(),
            fake.word().capitalize() + " " + random.choice(["Gadget", "Accessory", "Tool", "Device"]),
            random.choice(["Electronics", "Furniture", "Clothing", "Beauty", "Food"]),
            random.choice(["Premium", "Budget", "Luxury"]),
            round(random.uniform(10, 1000), 2)
        ])

print("csv_file generated successfully.")